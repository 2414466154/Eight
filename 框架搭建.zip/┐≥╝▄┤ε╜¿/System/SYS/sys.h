#ifndef _SYS_H_
#define _SYS_H_

#include <reg52.h>

#define uchar unsigned char
#define uint unsigned int

#endif