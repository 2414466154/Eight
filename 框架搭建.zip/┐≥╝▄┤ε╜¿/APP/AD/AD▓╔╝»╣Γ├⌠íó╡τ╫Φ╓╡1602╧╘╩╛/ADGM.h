#ifndef __ADGM_H__
#define __ADGM_H__

#define uint unsigned int
#define uchar unsigned char


#define AddWr 0x90   //д���ݵ�ַ 
#define AddRd 0x91   //�����ݵ�ַ
sbit SDA=P2^0;
sbit SCL=P2^1;
extern bit ack;
	
extern void _Nop(void);//I2C��ʱ����
extern void Start_I2c();
extern void Stop_I2c();
extern void  SendByte(unsigned char c);
extern uchar RcvByte();
extern void NoAck_I2c(void);
extern uchar ReadADC(unsigned char Chl);	 
#endif