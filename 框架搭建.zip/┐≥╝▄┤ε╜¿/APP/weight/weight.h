#ifndef __weight_H__
#define __weight_H__

#define uchar unsigned char
#define uint unsigned int
#define GapValue 1449
/*sbit wela    =  P2^6;
sbit dula    =  P2^7;*/




//�����ʶ
extern volatile bit FlagTest;		//��ʱ���Ա�־��ÿ0.5����λ��������0

extern unsigned long Weight_Maopi ;
extern unsigned long Weight_Maopi_0;
extern long Weight_Shiwu ;
extern unsigned int qupi;




extern void Display_Weight();
extern void Get_Weight();
extern void Get_Maopi();
extern void Delay_weight(unsigned int n);
extern void Delay__hx711_us(void);
extern unsigned long HX711_Read(void);
#endif
