#ifndef _DS1302_H_
#define _DS1302_H_


#define uchar unsigned char
#define uint unsigned int


	extern unsigned char Ds1302_Read_Data(unsigned char cmd);
	extern void Ds1302_Write_Data(unsigned char cmd, unsigned char dat);
	extern void Ds1302_Init();
	extern void Ds1302_Read_Time();
#endif