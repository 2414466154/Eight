#ifndef _LCD1602_H_
#define _LCD1602_H_
#define uchar unsigned char
#define uint  unsigned int
	sbit dula=P2^6;//����ܵĶ�ѡ�ź�
	sbit wela=P2^7; //����ܵ�λѡ�ź�


	sbit LCD_RS = P3^5;     /*����LCD���ƶ˿�*/        
	sbit LCD_RW = P3^6;
	sbit LCD_EN = P3^4;
	extern void lcd1602_delay(int ms);
	extern bit  lcd_busy();
	extern void lcd_wcmd(uchar cmd);
	extern void lcd_wdat(uchar dat);
	extern void lcd_pos(uchar pos);
	extern void lcd_init();
	extern void stable_1602();
  extern void Print_1602(int s,uchar str1[]);
	extern void flash();
#endif
