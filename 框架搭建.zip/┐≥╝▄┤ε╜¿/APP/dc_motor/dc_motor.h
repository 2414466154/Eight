#ifndef __dc_motor_H__
#define __dc_motor_H__



#define uint unsigned int
#define uchar unsigned char

sbit IN1=P1^2;
sbit IN2=P1^1;
//sbit IN3=P1^2;
//sbit IN4=P1^3;
sbit EN1=P1^4;
//sbit EN2=P1^5;



extern void InitSpeed();
extern void SetSpeed(unsigned int num);
extern void TurnLeft();
extern void TurnRight();
extern void MotorStop();

#endif