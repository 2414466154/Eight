#ifndef __ds18b20_H__
#define __ds18b20_H__



#define uint unsigned int
#define uchar unsigned char


sbit DQ =P2^2;  //����DS18B20ͨ�Ŷ˿�



extern void ds18b20_delay(uint i);
extern void Init_DS18B20();
extern uchar ReadOneChar();
extern void WriteOneChar(unsigned char dat);
extern uint ReadTemperature();

#endif