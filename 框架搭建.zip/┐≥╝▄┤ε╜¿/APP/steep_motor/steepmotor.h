#ifndef __steepmotor_H__
#define __steepmotor_H__

#define uchar unsigned char
#define uint unsigned int
	
extern void Delay_steepmotor(uint x);
extern void MotorStop(void);
extern void MotorCCW(void);
extern void MotorCW(void);

#endif