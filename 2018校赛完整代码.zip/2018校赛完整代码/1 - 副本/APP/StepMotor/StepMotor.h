#ifndef _STEPMOTOR_H_
#define _STEPMOTOR_H_

#include "sys.h"


/***********���Ŷ���**************/
sbit Step_A=P1^0;
sbit Step_AF=P1^1;
sbit Step_B=P1^2;
sbit Step_BF=P1^3;


/*********************************************/
extern void Step_Cor(uint x);//�����ת
extern void Step_Rev(uint x);//�����ת

#endif
