#include "DC_Motor.h"
#include "delay.h"


void Motor_Stop()
{
	M_IN1=0;		
}

void Motor1()
{
	M_IN1=1;
	delay_ms(1);
	M_IN1=0;
	delay_ms(6);		
}

void Motor2()
{
	M_IN1=1;
	delay_ms(2);
	M_IN1=0;
	delay_ms(1);		
}

void Motor3()
{
	M_IN1=1;
	delay_ms(5);
	M_IN1=0;
	delay_ms(1);		
}