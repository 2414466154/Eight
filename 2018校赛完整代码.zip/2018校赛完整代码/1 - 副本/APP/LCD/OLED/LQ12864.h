#ifndef _LQ12864_H_
#define _LQ12864_H_

#include "sys.h"
#include "delay.h"


/**************************************************************/
#define high 1
#define low 0

#define	Brightness	0xCF 
#define X_WIDTH 	128
#define Y_WIDTH 	64

/***********************���Ŷ���******************************/
sbit SCL=P1^3; //����ʱ��
sbit SDA=P1^2; //��������

/**********************��������*******************************/
void OLED_Fill(unsigned char bmp_dat);
void OLED_CLS(void);
void OLED_Init(void);
void OLED_P6x8Str(unsigned char x, y,unsigned char ch[]);
void OLED_P8x16Str(unsigned char x, y,unsigned char ch[]);
void OLED_P16x16Ch(unsigned char x, y, N);
void Draw_BMP(unsigned char x0, y0,x1, y1,unsigned char BMP[]);

#endif
