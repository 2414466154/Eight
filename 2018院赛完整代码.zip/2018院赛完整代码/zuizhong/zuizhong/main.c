#include "reg52.h"			
#include "temp.h"
#include "LCD.h"
#include"XPT2046.h"	
#include<intrins.h>	

typedef unsigned int u16;	
typedef unsigned char u8;

#define GPIO_KEY P1

sbit MOTOA = P2^0;
sbit MOTOB = P2^1;
sbit led = P2^2;
sbit beep = P2^3;

int character=0;
float temperature,max=0.0,min=1000.0,temperature1;

u8 KeyValue,temp;
u16 Tha,Tla;

uchar code dis1[] = {"c005"};
uchar dis2[9];	  //�¶�
u8 disp[6];		  //ad
u8 dmin[9];		  //minֵ
u8 dmax[9];		  //maxֵ
u8 alarm[8];

void delay(int ms)
{
    while(ms--)
	{
      uchar i;
	  for(i=0;i<250;i++)  
	   {
	    _nop_();			   
		_nop_();
		_nop_();
		_nop_();
	   }
	}
}		

void delay0(u16 us)
{
	while(us--);
}

void alarmh()
{
	beep = 1;
	delay0(10);
	beep = 0;
	delay0(40);
}
void alarml()
{
	beep = 1;
	delay0(50);
	beep = 0;
	delay0(10);
}

void ledh()
{
	led = 1;
	delay0(1000);
	led = 0;
	delay0(5000);
}
void ledl()
{
	led = 1;
	delay0(5000);
	led = 0;
	delay0(1000);
}

void KeyDown()
{
	char a=0;
	GPIO_KEY=0x0f;
	if(GPIO_KEY!=0x0f)//��ȡ�����Ƿ���
	{
		delay(10);//��ʱ10ms��������
		if(GPIO_KEY!=0x0f)//�ٴμ������Ƿ���
		{	
			//������
			GPIO_KEY=0X0F;
			switch(GPIO_KEY)
			{
				case(0X07):	KeyValue=0;break;
				case(0X0b):	KeyValue=1;break;
				case(0X0d): KeyValue=2;break;
				case(0X0e):	KeyValue=3;break;
			}
			//������
			GPIO_KEY=0XF0;
			switch(GPIO_KEY)
			{
				case(0X70):	KeyValue=KeyValue;break;
				case(0Xb0):	KeyValue=KeyValue+4;break;
				case(0Xd0): KeyValue=KeyValue+8;break;
				case(0Xe0):	KeyValue=KeyValue+12;break;
			}
			while((a<50)&&(GPIO_KEY!=0xf0))	 //��ⰴ�����ּ��
			{
				delay(10);
				a++;
			}
		}
	}
}


void datapros(int temp) 	 
{
   	float tp;
	u8 i;
	if(temp< 0)			
  	{
		dis2[0]='-';
		temp=temp-1;
		temp=~temp;
		tp=temp;
		temp=tp*0.0625*100+0.5;
  	}
 	else
  	{	
		dis2[0]=' ';		
		tp=temp;
		temp=tp*0.0625*100+0.5;
	}

	temperature = (temp/100) + 0.1*(temp%100/10) + 0.01*(temp%10);

	//�жϼ�⣬�л��¶ȸ�ʽ
	if(!character)
	{
		temp = temp;
		dis2[6] = 'C';		
	}
	if(character)
	{
		temp = (temperature*1.8+32)*100;
		dis2[6] = 'F';
	}

	dis2[1] = '0' + temp % 10000 / 1000;
	dis2[2] = '0' + temp % 1000 / 100;
	dis2[3] = '.';
	dis2[4] = '0' + temp % 100 / 10;
	dis2[5] = '0' + temp % 10;


	if(temperature > max)
	{
		max = temperature;
		while(dis2[i] != '\0')
    	{                      
     		dmax[i] = dis2[i];
			i++;
    	}
	}
	i = 0;
	if(temperature < min)
	{
		min = temperature;
		while(dis2[i] != '\0')
    	{                      
     		dmin[i] = dis2[i];
			i++;
    	}
	}
}

void dataprosa()
{
	u16 temp1;
	temp1 = Read_AD_Data(0x94);	
	disp[0]='0' + temp1/1000;//ǧλ
	disp[1]='0' + temp1%1000/100;//��λ
	disp[2]='0' + temp1%1000%100/10;//��λ
	disp[3]='.';
	disp[4]='0' + temp1%1000%100%10;
	temperature1 = (temp1/10) + 0.1*(temp1%10);		
}

void ADalarm()
{
	
	if(KeyValue == 4)
	{
		temp++;
		if(temp==10)
			temp = 0;
		KeyValue = 20;
	}
	if(temp%2)
	{
		alarm[0] = 'H';
		alarm[1] = ':';
	}
	else
	{
		alarm[0] = 'L';
		alarm[1] = ':';
	}
	if(KeyValue==5&&alarm[0]=='H')
	{
		Tha++;
		alarm[2] = '0' + Tha%10000/1000;
		alarm[3] = '0' + (Tha%1000)/100;
		alarm[4] = '0' + (Tha%100)/10;
		alarm[5] = '.' ;
		alarm[6] = '0' + (Tha%10);
		KeyValue = 20;
	}
	if(KeyValue==6&&alarm[0]=='H')
	{
		Tha--;
		alarm[2] = '0' + (Tha%10000/1000);
		alarm[3] = '0' + (Tha%1000/100);
		alarm[4] = '0' + (Tha%100/10);
		alarm[5] = '.' ;
		alarm[6] = '0' + (Tha%10);
		KeyValue = 20;
	}
	if(KeyValue==5&&alarm[0]=='L')
	{
		Tla++;
		alarm[2] = '0' + (Tla%10000/1000);
		alarm[3] = '0' + (Tla%1000/100);
		alarm[4] = '0' + (Tla%100/10);
		alarm[5] = '.' ;
		alarm[6] = '0' + (Tla%10);
		KeyValue = 20;
	}
	if(KeyValue==6&&alarm[0]=='L')
	{
		Tla--;
		alarm[2] = '0' + (Tla%10000/1000);
		alarm[3] = '0' + (Tla%1000/100);
		alarm[4] = '0' + (Tla%100/10);
		alarm[5] = '.' ;
		alarm[6] = '0' + (Tla%10);
		KeyValue = 20;
	}
}

void  main()
 {
    uchar i;
   	Tha = Read_AD_Data(0x94);
	Tla = Read_AD_Data(0x94);
    LcdInit();                     
  	Ds18b20Init();
	            
    i = 0;

	LcdWriteCom(0x80);
    while(dis1[i] != '\0')
    {                      
     	LcdWriteData(dis1[i]);
        i++;
    }
	delay(1000);
	
	LcdWriteCom(0x01);  //����

    while(1)
	{
		ADalarm();
		KeyDown();
		if(KeyValue==1)
		{
			character=~character;
			KeyValue = 20;
		}
		LcdWriteCom(0x80);           
    	i = 0;
		datapros(Ds18b20ReadTemp());
	    while(dis2[i] != '\0')
	    {	
	       LcdWriteData(dis2[i]);
	       i++;		  
	    }
		LcdWriteCom(0x80+0x40);

		dataprosa(); 
		i = 0;
		while(disp[i] != '\0')
	    {	
	       LcdWriteData(disp[i]);
	       i++;		  
	    }
		i = 0;
		if(KeyValue==2)
		{
			LcdWriteCom(0x88);
			while(dmax[i] != '\0')
		    {	
		       LcdWriteData(dmax[i]);
		       i++;		  
		    }
		}
		i = 0;
		if(KeyValue==3)
		{
			LcdWriteCom(0x88);
			while(dmin[i] != '\0')
		    {	
		       LcdWriteData(dmin[i]);
		       i++;		  
		    }
		}

		if(temperature1 > 28.6)
		{
			MOTOA = 1;
			MOTOB = 0;
		}
		else if(temperature1 < 15.3)
		{
			MOTOA = 0;
			MOTOB = 1;
		}
		else
		{
			MOTOA = 1;
			MOTOB = 1;
		}
		LcdWriteCom(0x88+0x40);           
    	i = 0;
	    while(alarm[i] != '\0')
	    {	
	       LcdWriteData(alarm[i]);
	       i++;		  
	    }
		if(temperature1*10 > Tha)
		{
			alarmh();
			ledh();
		}
		if(temperature1*10 < Tla)
		{
			alarml();
			ledl();
		}
	}
}